Use the following shortcode for buttons in WP admin:

- [ypdigital_button]Button [/ypdigital_button]

Use the following shortcode for the slick slider in WP admin:

- [ypdigital_slider autoplay="true" arrows="true"]

- [ypdigital_slide image="1691" caption="caption" /]

- [ypdigital_slide image="1686" caption="caption" /]

- [ypdigital_slide image="1045" caption="caption" /]

- [/ypdigital_slider]